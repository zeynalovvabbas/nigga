extern int userfunc2(int x);
