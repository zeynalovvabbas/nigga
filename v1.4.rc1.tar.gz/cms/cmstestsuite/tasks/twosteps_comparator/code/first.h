extern int userfunc1(int x);
